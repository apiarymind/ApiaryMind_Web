/** @type {import('next').NextConfig} */
const nextConfig = {
  // output: 'export', // Disabled because we need Server Actions
};

export default nextConfig;
